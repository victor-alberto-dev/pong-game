# assets-do-curso-pong-na-godot-4
Assets utilizados no curso "Pong na Godot 4", disponível no meu canal do YouTube, "Desenvolvendo Jogos".
